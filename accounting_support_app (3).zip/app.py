#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Веб-приложение: Сопровождение информационной системы бухгалтерского учёта
"""

from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, g
)
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from contextlib import contextmanager

app = Flask(__name__)
app.secret_key = "accounting-support-secret-key-2024-secure"

DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "support.db")


# ==================== База данных ====================

@contextmanager
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    try:
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        if "users" not in tables:
            conn.executescript("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    full_name TEXT NOT NULL,
                    email TEXT,
                    role TEXT NOT NULL DEFAULT 'user',
                    department TEXT,
                    phone TEXT,
                    is_active INTEGER DEFAULT 1,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE tickets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    category TEXT NOT NULL,
                    priority TEXT NOT NULL DEFAULT 'Средний',
                    status TEXT NOT NULL DEFAULT 'Новая',
                    requester TEXT NOT NULL,
                    department TEXT,
                    assigned_to TEXT,
                    created_by INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    resolution TEXT
                );
                CREATE TABLE knowledge (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    category TEXT NOT NULL,
                    content TEXT NOT NULL,
                    tags TEXT,
                    views INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE system_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    module_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    last_check TEXT NOT NULL,
                    message TEXT
                );
                CREATE TABLE employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    full_name TEXT NOT NULL,
                    position TEXT NOT NULL,
                    department TEXT NOT NULL,
                    email TEXT,
                    phone TEXT,
                    specialization TEXT,
                    is_active INTEGER DEFAULT 1,
                    user_id INTEGER,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE faq (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question TEXT NOT NULL,
                    answer TEXT NOT NULL,
                    category TEXT NOT NULL,
                    sort_order INTEGER DEFAULT 0,
                    is_published INTEGER DEFAULT 1,
                    views INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    username TEXT,
                    action TEXT NOT NULL,
                    entity_type TEXT,
                    entity_id INTEGER,
                    details TEXT,
                    ip_address TEXT,
                    created_at TEXT NOT NULL
                );
            """)
            conn.commit()
            seed_data(conn)
            conn.commit()
    finally:
        conn.close()


def seed_data(conn):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M")
    two_days = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M")
    three_days = (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d %H:%M")

    # Пользователи
    users = [
        ("admin", generate_password_hash("admin123"), "Администратор Системы", "admin@buh.local", "admin", "ИТ", "+7 (495) 111-00-01", 1, now),
        ("petrov", generate_password_hash("petrov123"), "Петров Владимир Иванович", "petrov@buh.local", "support", "ИТ-поддержка", "+7 (495) 111-00-02", 1, now),
        ("smirnov", generate_password_hash("smirnov123"), "Смирнов Алексей Константинович", "smirnov@buh.local", "support", "ИТ-поддержка", "+7 (495) 111-00-03", 1, now),
        ("ivanova", generate_password_hash("ivanova123"), "Иванова Анна Сергеевна", "ivanova@buh.local", "user", "Бухгалтерия", "+7 (495) 111-00-10", 1, now),
        ("kozlova", generate_password_hash("kozlova123"), "Козлова Елена Павловна", "kozlova@buh.local", "user", "Бухгалтерия", "+7 (495) 111-00-11", 1, now),
    ]
    conn.executemany(
        """INSERT INTO users (username, password_hash, full_name, email, role, department, phone, is_active, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        users
    )

    # Сотрудники службы поддержки
    employees = [
        ("Петров Владимир Иванович", "Ведущий специалист", "ИТ-поддержка", "petrov@buh.local", "+7 (495) 111-00-02", "Отчётность, НДС, ЭДО", 1, 2, now),
        ("Смирнов Алексей Константинович", "Специалист поддержки", "ИТ-поддержка", "smirnov@buh.local", "+7 (495) 111-00-03", "Зарплата, кадры, производительность", 1, 3, now),
        ("Кузнецова Мария Андреевна", "Специалист поддержки", "ИТ-поддержка", "kuznetsova@buh.local", "+7 (495) 111-00-04", "Справочники, документы, настройка", 1, None, now),
        ("Волков Дмитрий Сергеевич", "Инженер инфраструктуры", "ИТ", "volkov@buh.local", "+7 (495) 111-00-05", "Серверы, обмен с банком, интеграции", 1, None, now),
        ("Новикова Ольга Игоревна", "Руководитель службы поддержки", "ИТ-поддержка", "novikova@buh.local", "+7 (495) 111-00-06", "Управление, эскалация, SLA", 1, None, now),
    ]
    conn.executemany(
        """INSERT INTO employees (full_name, position, department, email, phone, specialization, is_active, user_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        employees
    )

    # Заявки
    tickets = [
        ("Ошибка при формировании отчёта по НДС",
         "При попытке сформировать декларацию по НДС за 3 квартал система выдаёт ошибку «Недостаточно данных по счёту 68».",
         "Отчётность", "Высокий", "В работе", "Иванова А.С.", "Бухгалтерия", "Петров В.И.", 4, yesterday, now, None),
        ("Не загружается справочник контрагентов",
         "После обновления системы справочник контрагентов открывается пустым. Ранее данные были.",
         "Справочники", "Критический", "Новая", "Сидоров К.М.", "Закупки", None, None, now, now, None),
        ("Требуется добавить новый вид операции",
         "Необходимо добавить операцию «Возврат товара поставщику» в журнал хозяйственных операций.",
         "Настройка", "Средний", "Новая", "Козлова Е.П.", "Бухгалтерия", None, 5, now, now, None),
        ("Проблема с выгрузкой в 1С-Отчётность",
         "Файлы обмена формируются, но не принимаются на стороне ФНС. Код ошибки 0400400011.",
         "Интеграция", "Высокий", "Решена", "Морозов Д.А.", "Бухгалтерия", "Петров В.И.", None, two_days, yesterday,
         "Обновлён сертификат ЭЦП и пересоздана выгрузка. Проблема устранена."),
        ("Медленная работа модуля «Зарплата»",
         "При расчёте зарплаты за октябрь система «зависает» на 3–5 минут на этапе начисления НДФЛ.",
         "Производительность", "Средний", "В работе", "Николаева О.В.", "Кадры", "Смирнов А.К.", None, yesterday, now, None),
        ("Ошибка округления в акте сверки",
         "В акте сверки с контрагентом «ООО Ромашка» сумма расходится на 0,01 руб. из-за округления.",
         "Документы", "Низкий", "Новая", "Фёдорова М.И.", "Бухгалтерия", None, None, now, now, None),
        ("Не приходят уведомления об ЭДО",
         "Входящие документы ЭДО не появляются в журнале, хотя в Диадоке они есть.",
         "Интеграция", "Высокий", "В работе", "Иванова А.С.", "Бухгалтерия", "Петров В.И.", 4, three_days, yesterday, None),
        ("Сброс пароля пользователя",
         "Пользователь Соколова Т.В. забыла пароль, требуется сброс доступа.",
         "Администрирование", "Низкий", "Решена", "Соколова Т.В.", "Склад", "Смирнов А.К.", None, three_days, two_days,
         "Пароль сброшен, временный пароль передан руководителю отдела."),
    ]
    conn.executemany(
        """INSERT INTO tickets (title, description, category, priority, status, requester, department, assigned_to, created_by, created_at, updated_at, resolution)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        tickets
    )

    # База знаний
    knowledge = [
        ("Как сформировать баланс за период", "Отчётность",
         """1. Перейдите в раздел «Отчёты» → «Бухгалтерская отчётность».
2. Выберите «Бухгалтерский баланс».
3. Укажите период и организацию.
4. Нажмите «Сформировать».
5. Для выгрузки в Excel используйте кнопку «Экспорт».

Если данные не совпадают с ОСВ — выполните перепроведение документов за период.""",
         "баланс, отчётность, ОСВ", now),
        ("Восстановление доступа пользователя", "Администрирование",
         """1. Зайдите под учётной записью администратора.
2. Откройте «Администрирование» → «Пользователи».
3. Найдите пользователя и снимите флаг «Заблокирован».
4. При необходимости сбросьте пароль через «Действия» → «Сменить пароль».
5. Сообщите пользователю временный пароль.

Важно: после 5 неудачных попыток входа учётная запись блокируется автоматически.""",
         "пользователи, пароль, доступ", now),
        ("Настройка обмена с банком", "Интеграция",
         """1. Перейдите в «Банк и касса» → «Настройка обмена».
2. Выберите банк из списка или создайте новый профиль.
3. Укажите путь к папке обмена или параметры API.
4. Загрузите сертификат электронной подписи.
5. Выполните тестовую выгрузку платёжного поручения.

Поддерживаются форматы: 1CClientBankExchange, ISO 20022.""",
         "банк, обмен, платёжки", now),
        ("Типовые ошибки при закрытии месяца", "Регламентные операции",
         """Частые проблемы:
• Не закрыт счёт 20/23/25/26 — проверьте распределение затрат.
• Остатки по счетам учёта НДС — выполните «Формирование записей книги покупок/продаж».
• Ошибка курсовых разниц — перепроведите документы в валюте.
• Не рассчитана амортизация — запустите регламентную операцию «Амортизация ОС и НМА».

Рекомендуется выполнять закрытие месяца последовательно по всем этапам.""",
         "закрытие месяца, регламент, ошибки", now),
        ("Работа с электронными первичными документами", "Документы",
         """Система поддерживает ЭДО через операторов Контур.Диадок, СБИС, Такском.

1. В карточке контрагента укажите идентификатор ЭДО.
2. При создании документа выберите «Отправить через ЭДО».
3. Подпишите документ квалифицированной ЭП.
4. Статус документа отслеживается в журнале «ЭДО».

Входящие документы автоматически создают черновики в системе учёта.""",
         "ЭДО, документы, подпись", now),
    ]
    conn.executemany(
        """INSERT INTO knowledge (title, category, content, tags, created_at)
           VALUES (?, ?, ?, ?, ?)""",
        knowledge
    )

    # Статусы модулей
    modules = [
        ("Главная книга", "Работает", now, "Все операции проводятся корректно"),
        ("Расчёт зарплаты", "Предупреждение", now, "Повышенная нагрузка при массовом расчёте"),
        ("Банк и касса", "Работает", now, "Обмен с банком активен"),
        ("НДС и отчётность", "Работает", now, "Формирование отчётов без ошибок"),
        ("Справочники", "Ошибка", now, "Проблема с загрузкой контрагентов"),
        ("Основные средства", "Работает", now, "Амортизация рассчитана"),
        ("Складской учёт", "Работает", now, "Остатки актуальны"),
        ("ЭДО", "Работает", now, "Соединение с операторами стабильно"),
    ]
    conn.executemany(
        """INSERT INTO system_status (module_name, status, last_check, message)
           VALUES (?, ?, ?, ?)""",
        modules
    )

    # FAQ
    faqs = [
        ("Как создать заявку на поддержку?",
         "Перейдите в раздел «Заявки» → «Создать заявку». Заполните тему, описание, категорию и приоритет. После отправки заявка появится в общем списке и будет назначена специалисту.",
         "Общие", 1, 1, 42, now),
        ("Какие сроки решения заявок (SLA)?",
         "Критический — 4 часа; Высокий — 1 рабочий день; Средний — 3 рабочих дня; Низкий — 5 рабочих дней. Срок отсчитывается с момента регистрации заявки в рабочие часы (Пн–Пт, 9:00–18:00).",
         "Общие", 2, 1, 38, now),
        ("Как сбросить пароль в учётной системе?",
         "Обратитесь к администратору или создайте заявку категории «Администрирование». Самостоятельный сброс пароля через портал пока не предусмотрен. Временный пароль передаётся лично или через руководителя отдела.",
         "Доступ", 3, 1, 55, now),
        ("Почему не формируется отчёт по НДС?",
         "Чаще всего причина — незакрытые документы или отсутствие данных по счёту 68. Выполните перепроведение документов за период и регламентную операцию «Формирование записей книги покупок/продаж». Подробнее — в базе знаний.",
         "Отчётность", 4, 1, 29, now),
        ("Как подключить обмен с банком?",
         "Раздел «Банк и касса» → «Настройка обмена». Выберите банк, укажите параметры и загрузите сертификат ЭП. Инструкция есть в базе знаний («Настройка обмена с банком»).",
         "Интеграция", 5, 1, 21, now),
        ("Что делать, если модуль «завис»?",
         "Обновите страницу (F5). Если не помогает — закройте браузер и войдите заново. При повторении создайте заявку категории «Производительность» с указанием модуля и времени возникновения.",
         "Производительность", 6, 1, 17, now),
        ("Куда обращаться в нерабочее время?",
         "Для критических инцидентов (полная недоступность системы) звоните на дежурный номер +7 (495) 111-00-99. Остальные обращения регистрируйте через портал — они будут обработаны в начале следующего рабочего дня.",
         "Общие", 7, 1, 33, now),
        ("Как отследить статус своей заявки?",
         "В разделе «Заявки» найдите свою заявку по номеру или теме. В карточке отображаются статус, исполнитель и решение (если заявка закрыта).",
         "Общие", 8, 1, 47, now),
    ]
    conn.executemany(
        """INSERT INTO faq (question, answer, category, sort_order, is_published, views, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        faqs
    )

    # Аудит
    audit = [
        (1, "admin", "login", "user", 1, "Вход в систему", "127.0.0.1", three_days),
        (1, "admin", "create", "ticket", 1, "Создана заявка (демо)", "127.0.0.1", three_days),
        (2, "petrov", "login", "user", 2, "Вход в систему", "127.0.0.1", two_days),
        (2, "petrov", "update", "ticket", 4, "Статус изменён на «Решена»", "127.0.0.1", yesterday),
        (3, "smirnov", "login", "user", 3, "Вход в систему", "127.0.0.1", yesterday),
        (3, "smirnov", "update", "ticket", 8, "Статус изменён на «Решена»", "127.0.0.1", two_days),
        (4, "ivanova", "login", "user", 4, "Вход в систему", "127.0.0.1", yesterday),
        (4, "ivanova", "create", "ticket", 1, "Создана заявка по НДС", "127.0.0.1", yesterday),
        (1, "admin", "view", "audit", None, "Просмотр журнала аудита", "127.0.0.1", now),
    ]
    conn.executemany(
        """INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, details, ip_address, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        audit
    )


def log_audit(action, entity_type=None, entity_id=None, details=None):
    user_id = session.get("user_id")
    username = session.get("username", "anonymous")
    ip = request.remote_addr or "—"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with get_db() as conn:
            conn.execute(
                """INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, details, ip_address, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (user_id, username, action, entity_type, entity_id, details, ip, now),
            )
    except Exception:
        pass


# ==================== Auth helpers ====================

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            flash("Для доступа необходимо войти в систему", "danger")
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return decorated


def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if "user_id" not in session:
                flash("Для доступа необходимо войти в систему", "danger")
                return redirect(url_for("login", next=request.path))
            if session.get("role") not in roles:
                flash("Недостаточно прав для этого действия", "danger")
                return redirect(url_for("index"))
            return f(*args, **kwargs)
        return decorated
    return decorator


@app.before_request
def load_user():
    g.user = None
    if "user_id" in session:
        with get_db() as conn:
            g.user = conn.execute(
                "SELECT * FROM users WHERE id = ? AND is_active = 1",
                (session["user_id"],),
            ).fetchone()
        if not g.user:
            session.clear()


# ==================== Auth routes ====================

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with get_db() as conn:
            user = conn.execute(
                "SELECT * FROM users WHERE username = ? AND is_active = 1",
                (username,),
            ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            log_audit("login", "user", user["id"], f"Вход пользователя {user['username']}")
            flash(f"Добро пожаловать, {user['full_name']}!", "success")
            next_url = request.args.get("next") or url_for("index")
            return redirect(next_url)
        flash("Неверный логин или пароль", "danger")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip()
        department = request.form.get("department", "").strip()
        phone = request.form.get("phone", "").strip()

        if not all([username, password, full_name]):
            flash("Заполните обязательные поля", "danger")
            return render_template("register.html")
        if password != password2:
            flash("Пароли не совпадают", "danger")
            return render_template("register.html")
        if len(password) < 6:
            flash("Пароль должен быть не короче 6 символов", "danger")
            return render_template("register.html")

        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        try:
            with get_db() as conn:
                conn.execute(
                    """INSERT INTO users (username, password_hash, full_name, email, role, department, phone, is_active, created_at)
                       VALUES (?, ?, ?, ?, 'user', ?, ?, 1, ?)""",
                    (username, generate_password_hash(password), full_name, email or None, department or None, phone or None, now),
                )
            flash("Регистрация успешна! Войдите в систему.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Пользователь с таким логином уже существует", "danger")
    return render_template("register.html")


@app.route("/logout")
def logout():
    if "user_id" in session:
        log_audit("logout", "user", session.get("user_id"), f"Выход пользователя {session.get('username')}")
    session.clear()
    flash("Вы вышли из системы", "success")
    return redirect(url_for("login"))


# ==================== Основные маршруты ====================

@app.route("/")
@login_required
def index():
    with get_db() as conn:
        stats = {
            "total": conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0],
            "new": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Новая'").fetchone()[0],
            "in_progress": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'В работе'").fetchone()[0],
            "resolved": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Решена'").fetchone()[0],
            "critical": conn.execute("SELECT COUNT(*) FROM tickets WHERE priority = 'Критический' AND status != 'Решена'").fetchone()[0],
        }
        recent = conn.execute(
            "SELECT * FROM tickets ORDER BY created_at DESC LIMIT 5"
        ).fetchall()
        modules = conn.execute("SELECT * FROM system_status ORDER BY module_name").fetchall()
    return render_template("index.html", stats=stats, recent=recent, modules=modules)


@app.route("/tickets")
@login_required
def tickets():
    status_filter = request.args.get("status", "")
    priority_filter = request.args.get("priority", "")
    category_filter = request.args.get("category", "")
    department_filter = request.args.get("department", "")
    assignee_filter = request.args.get("assignee", "")
    search = request.args.get("q", "").strip()
    sort = request.args.get("sort", "priority")  # priority | date_desc | date_asc

    query = "SELECT * FROM tickets WHERE 1=1"
    params = []
    if status_filter:
        query += " AND status = ?"
        params.append(status_filter)
    if priority_filter:
        query += " AND priority = ?"
        params.append(priority_filter)
    if category_filter:
        query += " AND category = ?"
        params.append(category_filter)
    if department_filter:
        query += " AND department = ?"
        params.append(department_filter)
    if assignee_filter:
        if assignee_filter == "__none__":
            query += " AND (assigned_to IS NULL OR assigned_to = '')"
        else:
            query += " AND assigned_to = ?"
            params.append(assignee_filter)
    if search:
        query += """ AND (
            title LIKE ? OR description LIKE ? OR requester LIKE ?
            OR COALESCE(department, '') LIKE ? OR COALESCE(assigned_to, '') LIKE ?
            OR CAST(id AS TEXT) LIKE ?
        )"""
        like = f"%{search}%"
        params.extend([like, like, like, like, like, like])

    if sort == "date_asc":
        query += " ORDER BY created_at ASC"
    elif sort == "date_desc":
        query += " ORDER BY created_at DESC"
    else:
        query += " ORDER BY CASE priority WHEN 'Критический' THEN 1 WHEN 'Высокий' THEN 2 WHEN 'Средний' THEN 3 ELSE 4 END, created_at DESC"

    with get_db() as conn:
        tickets_list = conn.execute(query, params).fetchall()
        categories = [r[0] for r in conn.execute("SELECT DISTINCT category FROM tickets ORDER BY category").fetchall()]
        departments = [r[0] for r in conn.execute(
            "SELECT DISTINCT department FROM tickets WHERE department IS NOT NULL AND department != '' ORDER BY department"
        ).fetchall()]
        assignees = [r[0] for r in conn.execute(
            "SELECT DISTINCT assigned_to FROM tickets WHERE assigned_to IS NOT NULL AND assigned_to != '' ORDER BY assigned_to"
        ).fetchall()]
        total_count = conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0]

    return render_template(
        "tickets.html",
        tickets=tickets_list,
        categories=categories,
        departments=departments,
        assignees=assignees,
        status_filter=status_filter,
        priority_filter=priority_filter,
        category_filter=category_filter,
        department_filter=department_filter,
        assignee_filter=assignee_filter,
        search=search,
        sort=sort,
        total_count=total_count,
        found_count=len(tickets_list),
    )


@app.route("/tickets/<int:ticket_id>")
@login_required
def ticket_detail(ticket_id):
    with get_db() as conn:
        ticket = conn.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
        employees = conn.execute(
            "SELECT full_name FROM employees WHERE is_active = 1 ORDER BY full_name"
        ).fetchall()
    if not ticket:
        flash("Заявка не найдена", "danger")
        return redirect(url_for("tickets"))
    return render_template("ticket_detail.html", ticket=ticket, employees=employees)


@app.route("/tickets/new", methods=["GET", "POST"])
@login_required
def new_ticket():
    categories = [
        "Отчётность", "Справочники", "Настройка", "Интеграция",
        "Производительность", "Документы", "Администрирование", "Прочее",
    ]
    # данные текущего пользователя для подстановки
    user_dept = ""
    if g.user:
        user_dept = g.user["department"] or ""

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "").strip()
        priority = request.form.get("priority", "Средний")
        requester = request.form.get("requester", "").strip() or session.get("full_name", "")
        department = request.form.get("department", "").strip()

        if not title or not description or not category or not requester:
            flash("Заполните все обязательные поля (тема, описание, категория, заявитель)", "danger")
            return render_template(
                "new_ticket.html",
                categories=categories,
                form={
                    "title": title,
                    "description": description,
                    "category": category,
                    "priority": priority,
                    "requester": requester,
                    "department": department,
                },
                user_dept=user_dept,
            )

        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        with get_db() as conn:
            cur = conn.execute(
                """INSERT INTO tickets (title, description, category, priority, status, requester, department, created_by, created_at, updated_at)
                   VALUES (?, ?, ?, ?, 'Новая', ?, ?, ?, ?, ?)""",
                (title, description, category, priority, requester, department or None, session.get("user_id"), now, now),
            )
            ticket_id = cur.lastrowid
        log_audit("create", "ticket", ticket_id, f"Создана заявка: {title}")
        flash(f"Заявка #{ticket_id} успешно создана", "success")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))

    return render_template(
        "new_ticket.html",
        categories=categories,
        form={
            "title": "",
            "description": "",
            "category": "",
            "priority": "Средний",
            "requester": session.get("full_name", ""),
            "department": user_dept,
        },
        user_dept=user_dept,
    )


@app.route("/tickets/<int:ticket_id>/update", methods=["POST"])
@login_required
def update_ticket(ticket_id):
    status = request.form.get("status")
    assigned_to = request.form.get("assigned_to", "").strip()
    resolution = request.form.get("resolution", "").strip()
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    with get_db() as conn:
        conn.execute(
            """UPDATE tickets SET status = ?, assigned_to = ?, resolution = ?, updated_at = ?
               WHERE id = ?""",
            (status, assigned_to or None, resolution or None, now, ticket_id),
        )
    log_audit("update", "ticket", ticket_id, f"Статус: {status}, исполнитель: {assigned_to or '—'}")
    flash("Заявка обновлена", "success")
    return redirect(url_for("ticket_detail", ticket_id=ticket_id))


@app.route("/knowledge")
@login_required
def knowledge():
    category = request.args.get("category", "")
    search = request.args.get("q", "").strip()
    query = "SELECT * FROM knowledge WHERE 1=1"
    params = []
    if category:
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)"
        params.extend([f"%{search}%"] * 3)
    query += " ORDER BY views DESC, title"
    with get_db() as conn:
        articles = conn.execute(query, params).fetchall()
        categories = [r[0] for r in conn.execute("SELECT DISTINCT category FROM knowledge ORDER BY category").fetchall()]
    return render_template("knowledge.html", articles=articles, categories=categories, current_category=category, search=search)


@app.route("/knowledge/<int:article_id>")
@login_required
def knowledge_detail(article_id):
    with get_db() as conn:
        conn.execute("UPDATE knowledge SET views = views + 1 WHERE id = ?", (article_id,))
        article = conn.execute("SELECT * FROM knowledge WHERE id = ?", (article_id,)).fetchone()
    if not article:
        flash("Статья не найдена", "danger")
        return redirect(url_for("knowledge"))
    return render_template("knowledge_detail.html", article=article)


@app.route("/status")
@login_required
def system_status():
    with get_db() as conn:
        modules = conn.execute("SELECT * FROM system_status ORDER BY module_name").fetchall()
    return render_template("status.html", modules=modules)


@app.route("/about")
@login_required
def about():
    return render_template("about.html")


# ==================== Сотрудники ====================

@app.route("/employees")
@login_required
def employees():
    dept = request.args.get("department", "")
    query = "SELECT * FROM employees WHERE is_active = 1"
    params = []
    if dept:
        query += " AND department = ?"
        params.append(dept)
    query += " ORDER BY department, full_name"
    with get_db() as conn:
        emps = conn.execute(query, params).fetchall()
        departments = [r[0] for r in conn.execute("SELECT DISTINCT department FROM employees WHERE is_active = 1 ORDER BY department").fetchall()]
    return render_template("employees.html", employees=emps, departments=departments, current_dept=dept)


# ==================== FAQ ====================

@app.route("/faq")
@login_required
def faq():
    category = request.args.get("category", "")
    query = "SELECT * FROM faq WHERE is_published = 1"
    params = []
    if category:
        query += " AND category = ?"
        params.append(category)
    query += " ORDER BY sort_order, id"
    with get_db() as conn:
        items = conn.execute(query, params).fetchall()
        categories = [r[0] for r in conn.execute("SELECT DISTINCT category FROM faq WHERE is_published = 1 ORDER BY category").fetchall()]
    return render_template("faq.html", items=items, categories=categories, current_category=category)


@app.route("/faq/<int:faq_id>")
@login_required
def faq_view(faq_id):
    with get_db() as conn:
        conn.execute("UPDATE faq SET views = views + 1 WHERE id = ?", (faq_id,))
        item = conn.execute("SELECT * FROM faq WHERE id = ? AND is_published = 1", (faq_id,)).fetchone()
    if not item:
        flash("Вопрос не найден", "danger")
        return redirect(url_for("faq"))
    return render_template("faq_detail.html", item=item)


# ==================== Статистика ====================

@app.route("/statistics")
@login_required
def statistics():
    with get_db() as conn:
        by_status = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM tickets GROUP BY status ORDER BY cnt DESC"
        ).fetchall()
        by_priority = conn.execute(
            "SELECT priority, COUNT(*) as cnt FROM tickets GROUP BY priority"
        ).fetchall()
        by_category = conn.execute(
            "SELECT category, COUNT(*) as cnt FROM tickets GROUP BY category ORDER BY cnt DESC"
        ).fetchall()
        by_assignee = conn.execute(
            """SELECT COALESCE(assigned_to, 'Не назначен') as name, COUNT(*) as cnt
               FROM tickets GROUP BY assigned_to ORDER BY cnt DESC"""
        ).fetchall()
        totals = {
            "tickets": conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0],
            "resolved": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Решена'").fetchone()[0],
            "open": conn.execute("SELECT COUNT(*) FROM tickets WHERE status != 'Решена'").fetchone()[0],
            "users": conn.execute("SELECT COUNT(*) FROM users WHERE is_active = 1").fetchone()[0],
            "employees": conn.execute("SELECT COUNT(*) FROM employees WHERE is_active = 1").fetchone()[0],
            "knowledge": conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0],
            "faq": conn.execute("SELECT COUNT(*) FROM faq WHERE is_published = 1").fetchone()[0],
            "audit": conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0],
        }
        recent_resolved = conn.execute(
            "SELECT * FROM tickets WHERE status = 'Решена' ORDER BY updated_at DESC LIMIT 5"
        ).fetchall()
        top_knowledge = conn.execute(
            "SELECT id, title, views, category FROM knowledge ORDER BY views DESC LIMIT 5"
        ).fetchall()

    # Порядок приоритетов для отображения
    priority_order = {"Критический": 0, "Высокий": 1, "Средний": 2, "Низкий": 3}
    by_priority = sorted(by_priority, key=lambda x: priority_order.get(x["priority"], 99))

    return render_template(
        "statistics.html",
        by_status=by_status,
        by_priority=by_priority,
        by_category=by_category,
        by_assignee=by_assignee,
        totals=totals,
        recent_resolved=recent_resolved,
        top_knowledge=top_knowledge,
    )


# ==================== Журнал аудита ====================

@app.route("/audit")
@login_required
@role_required("admin", "support")
def audit():
    action_filter = request.args.get("action", "")
    user_filter = request.args.get("user", "")
    query = "SELECT * FROM audit_log WHERE 1=1"
    params = []
    if action_filter:
        query += " AND action = ?"
        params.append(action_filter)
    if user_filter:
        query += " AND username LIKE ?"
        params.append(f"%{user_filter}%")
    query += " ORDER BY created_at DESC, id DESC LIMIT 200"
    with get_db() as conn:
        logs = conn.execute(query, params).fetchall()
        actions = [r[0] for r in conn.execute("SELECT DISTINCT action FROM audit_log ORDER BY action").fetchall()]
    log_audit("view", "audit", None, "Просмотр журнала аудита")
    return render_template("audit.html", logs=logs, actions=actions, action_filter=action_filter, user_filter=user_filter)


# ==================== Запуск ====================

if __name__ == "__main__":
    init_db()
    print("=" * 60)
    print("  Сопровождение ИС бухгалтерского учёта")
    print("  http://127.0.0.1:5000")
    print()
    print("  Демо-доступ:")
    print("    admin / admin123     (администратор)")
    print("    petrov / petrov123   (поддержка)")
    print("    ivanova / ivanova123 (пользователь)")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5000, debug=True)
