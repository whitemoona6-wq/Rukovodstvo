#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Веб-приложение: Сопровождение информационной системы бухгалтерского учёта
"""

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime, timedelta
import sqlite3
import os
from contextlib import contextmanager

app = Flask(__name__)
app.secret_key = "accounting-support-secret-key-2024"

DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "support.db")


# ==================== База данных ====================

@contextmanager
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                category TEXT NOT NULL,
                priority TEXT NOT NULL DEFAULT 'Средний',
                status TEXT NOT NULL DEFAULT 'Новая',
                requester TEXT NOT NULL,
                department TEXT,
                assigned_to TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                resolution TEXT
            );

            CREATE TABLE IF NOT EXISTS knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                tags TEXT,
                views INTEGER DEFAULT 0,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS system_status (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                module_name TEXT NOT NULL,
                status TEXT NOT NULL,
                last_check TEXT NOT NULL,
                message TEXT
            );
        """)

        # Проверяем, есть ли уже данные
        count = conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0]
        if count == 0:
            seed_data(conn)


def seed_data(conn):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M")
    two_days = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M")

    tickets = [
        ("Ошибка при формировании отчёта по НДС",
         "При попытке сформировать декларацию по НДС за 3 квартал система выдаёт ошибку «Недостаточно данных по счёту 68».",
         "Отчётность", "Высокий", "В работе", "Иванова А.С.", "Бухгалтерия", "Петров В.И.", yesterday, now, None),
        ("Не загружается справочник контрагентов",
         "После обновления системы справочник контрагентов открывается пустым. Ранее данные были.",
         "Справочники", "Критический", "Новая", "Сидоров К.М.", "Закупки", None, now, now, None),
        ("Требуется добавить новый вид операции",
         "Необходимо добавить операцию «Возврат товара поставщику» в журнал хозяйственных операций.",
         "Настройка", "Средний", "Новая", "Козлова Е.П.", "Бухгалтерия", None, now, now, None),
        ("Проблема с выгрузкой в 1С-Отчётность",
         "Файлы обмена формируются, но не принимаются на стороне ФНС. Код ошибки 0400400011.",
         "Интеграция", "Высокий", "Решена", "Морозов Д.А.", "Бухгалтерия", "Петров В.И.", two_days, yesterday,
         "Обновлён сертификат ЭЦП и пересоздана выгрузка. Проблема устранена."),
        ("Медленная работа модуля «Зарплата»",
         "При расчёте зарплаты за октябрь система «зависает» на 3–5 минут на этапе начисления НДФЛ.",
         "Производительность", "Средний", "В работе", "Николаева О.В.", "Кадры", "Смирнов А.К.", yesterday, now, None),
        ("Ошибка округления в акте сверки",
         "В акте сверки с контрагентом «ООО Ромашка» сумма расходится на 0,01 руб. из-за округления.",
         "Документы", "Низкий", "Новая", "Фёдорова М.И.", "Бухгалтерия", None, now, now, None),
    ]

    conn.executemany(
        """INSERT INTO tickets (title, description, category, priority, status, requester, department, assigned_to, created_at, updated_at, resolution)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        tickets
    )

    knowledge = [
        ("Как сформировать баланс за период", "Отчётность",
         """1. Перейдите в раздел «Отчёты» → «Бухгалтерская отчётность».
2. Выберите «Бухгалтерский баланс».
3. Укажите период и организацию.
4. Нажмите «Сформировать».
5. Для выгрузки в Excel используйте кнопку «Экспорт».

Если данные не совпадают с ОСВ — выполните перепроведение документов за период.""",
         "баланс, отчётность, ОСВ", now),

        ("Восстановление доступа пользователя", "Администрирование",
         """1. Зайдите под учётной записью администратора.
2. Откройте «Администрирование» → «Пользователи».
3. Найдите пользователя и снимите флаг «Заблокирован».
4. При необходимости сбросьте пароль через «Действия» → «Сменить пароль».
5. Сообщите пользователю временный пароль.

Важно: после 5 неудачных попыток входа учётная запись блокируется автоматически.""",
         "пользователи, пароль, доступ", now),

        ("Настройка обмена с банком", "Интеграция",
         """1. Перейдите в «Банк и касса» → «Настройка обмена».
2. Выберите банк из списка или создайте новый профиль.
3. Укажите путь к папке обмена или параметры API.
4. Загрузите сертификат электронной подписи.
5. Выполните тестовую выгрузку платёжного поручения.

Поддерживаются форматы: 1CClientBankExchange, ISO 20022.""",
         "банк, обмен, платёжки", now),

        ("Типовые ошибки при закрытии месяца", "Регламентные операции",
         """Частые проблемы:
• Не закрыт счёт 20/23/25/26 — проверьте распределение затрат.
• Остатки по счетам учёта НДС — выполните «Формирование записей книги покупок/продаж».
• Ошибка курсовых разниц — перепроведите документы в валюте.
• Не рассчитана амортизация — запустите регламентную операцию «Амортизация ОС и НМА».

Рекомендуется выполнять закрытие месяца последовательно по всем этапам.""",
         "закрытие месяца, регламент, ошибки", now),

        ("Работа с электронными первичными документами", "Документы",
         """Система поддерживает ЭДО через операторов Контур.Диадок, СБИС, Такском.

1. В карточке контрагента укажите идентификатор ЭДО.
2. При создании документа выберите «Отправить через ЭДО».
3. Подпишите документ квалифицированной ЭП.
4. Статус документа отслеживается в журнале «ЭДО».

Входящие документы автоматически создают черновики в системе учёта.""",
         "ЭДО, документы, подпись", now),
    ]

    conn.executemany(
        """INSERT INTO knowledge (title, category, content, tags, created_at)
           VALUES (?, ?, ?, ?, ?)""",
        knowledge
    )

    modules = [
        ("Главная книга", "Работает", now, "Все операции проводятся корректно"),
        ("Расчёт зарплаты", "Предупреждение", now, "Повышенная нагрузка при массовом расчёте"),
        ("Банк и касса", "Работает", now, "Обмен с банком активен"),
        ("НДС и отчётность", "Работает", now, "Формирование отчётов без ошибок"),
        ("Справочники", "Ошибка", now, "Проблема с загрузкой контрагентов"),
        ("Основные средства", "Работает", now, "Амортизация рассчитана"),
        ("Складской учёт", "Работает", now, "Остатки актуальны"),
        ("ЭДО", "Работает", now, "Соединение с операторами стабильно"),
    ]

    conn.executemany(
        """INSERT INTO system_status (module_name, status, last_check, message)
           VALUES (?, ?, ?, ?)""",
        modules
    )


# ==================== Маршруты ====================

@app.route("/")
def index():
    with get_db() as conn:
        stats = {
            "total": conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0],
            "new": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Новая'").fetchone()[0],
            "in_progress": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'В работе'").fetchone()[0],
            "resolved": conn.execute("SELECT COUNT(*) FROM tickets WHERE status = 'Решена'").fetchone()[0],
            "critical": conn.execute("SELECT COUNT(*) FROM tickets WHERE priority = 'Критический' AND status != 'Решена'").fetchone()[0],
        }
        recent = conn.execute(
            "SELECT * FROM tickets ORDER BY created_at DESC LIMIT 5"
        ).fetchall()
        modules = conn.execute("SELECT * FROM system_status ORDER BY module_name").fetchall()
    return render_template("index.html", stats=stats, recent=recent, modules=modules)


@app.route("/tickets")
def tickets():
    status_filter = request.args.get("status", "")
    priority_filter = request.args.get("priority", "")
    category_filter = request.args.get("category", "")

    query = "SELECT * FROM tickets WHERE 1=1"
    params = []

    if status_filter:
        query += " AND status = ?"
        params.append(status_filter)
    if priority_filter:
        query += " AND priority = ?"
        params.append(priority_filter)
    if category_filter:
        query += " AND category = ?"
        params.append(category_filter)

    query += " ORDER BY CASE priority WHEN 'Критический' THEN 1 WHEN 'Высокий' THEN 2 WHEN 'Средний' THEN 3 ELSE 4 END, created_at DESC"

    with get_db() as conn:
        tickets_list = conn.execute(query, params).fetchall()
        categories = [r[0] for r in conn.execute("SELECT DISTINCT category FROM tickets ORDER BY category").fetchall()]

    return render_template(
        "tickets.html",
        tickets=tickets_list,
        categories=categories,
        status_filter=status_filter,
        priority_filter=priority_filter,
        category_filter=category_filter,
    )


@app.route("/tickets/<int:ticket_id>")
def ticket_detail(ticket_id):
    with get_db() as conn:
        ticket = conn.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
    if not ticket:
        flash("Заявка не найдена", "danger")
        return redirect(url_for("tickets"))
    return render_template("ticket_detail.html", ticket=ticket)


@app.route("/tickets/new", methods=["GET", "POST"])
def new_ticket():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "").strip()
        priority = request.form.get("priority", "Средний")
        requester = request.form.get("requester", "").strip()
        department = request.form.get("department", "").strip()

        if not all([title, description, category, requester]):
            flash("Заполните все обязательные поля", "danger")
            return redirect(url_for("new_ticket"))

        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        with get_db() as conn:
            conn.execute(
                """INSERT INTO tickets (title, description, category, priority, status, requester, department, created_at, updated_at)
                   VALUES (?, ?, ?, ?, 'Новая', ?, ?, ?, ?)""",
                (title, description, category, priority, requester, department, now, now),
            )
        flash("Заявка успешно создана", "success")
        return redirect(url_for("tickets"))

    categories = ["Отчётность", "Справочники", "Настройка", "Интеграция", "Производительность", "Документы", "Администрирование", "Прочее"]
    return render_template("new_ticket.html", categories=categories)


@app.route("/tickets/<int:ticket_id>/update", methods=["POST"])
def update_ticket(ticket_id):
    status = request.form.get("status")
    assigned_to = request.form.get("assigned_to", "").strip()
    resolution = request.form.get("resolution", "").strip()
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    with get_db() as conn:
        conn.execute(
            """UPDATE tickets SET status = ?, assigned_to = ?, resolution = ?, updated_at = ?
               WHERE id = ?""",
            (status, assigned_to or None, resolution or None, now, ticket_id),
        )
    flash("Заявка обновлена", "success")
    return redirect(url_for("ticket_detail", ticket_id=ticket_id))


@app.route("/knowledge")
def knowledge():
    category = request.args.get("category", "")
    search = request.args.get("q", "").strip()

    query = "SELECT * FROM knowledge WHERE 1=1"
    params = []

    if category:
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)"
        params.extend([f"%{search}%"] * 3)

    query += " ORDER BY views DESC, title"

    with get_db() as conn:
        articles = conn.execute(query, params).fetchall()
        categories = [r[0] for r in conn.execute("SELECT DISTINCT category FROM knowledge ORDER BY category").fetchall()]

    return render_template("knowledge.html", articles=articles, categories=categories, current_category=category, search=search)


@app.route("/knowledge/<int:article_id>")
def knowledge_detail(article_id):
    with get_db() as conn:
        conn.execute("UPDATE knowledge SET views = views + 1 WHERE id = ?", (article_id,))
        article = conn.execute("SELECT * FROM knowledge WHERE id = ?", (article_id,)).fetchone()
    if not article:
        flash("Статья не найдена", "danger")
        return redirect(url_for("knowledge"))
    return render_template("knowledge_detail.html", article=article)


@app.route("/status")
def system_status():
    with get_db() as conn:
        modules = conn.execute("SELECT * FROM system_status ORDER BY module_name").fetchall()
    return render_template("status.html", modules=modules)


@app.route("/about")
def about():
    return render_template("about.html")


# ==================== Запуск ====================

if __name__ == "__main__":
    init_db()
    print("=" * 60)
    print("  Сопровождение ИС бухгалтерского учёта")
    print("  Приложение запущено: http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5000, debug=True)
