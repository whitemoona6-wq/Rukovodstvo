#!/usr/bin/env python3
"""
ИС «Учёт техники» — веб-приложение
Запуск: python app.py
Откроется на http://127.0.0.1:5000
"""

from flask import Flask, send_from_directory
import os
import webbrowser
from threading import Timer

app = Flask(__name__, static_folder='.', static_url_path='')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


@app.route('/')
def index():
    return send_from_directory(BASE_DIR, 'index.html')


@app.route('/<path:path>')
def static_files(path):
    return send_from_directory(BASE_DIR, path)


def open_browser():
    webbrowser.open_new('http://127.0.0.1:5000')


if __name__ == '__main__':
    print('=' * 50)
    print('  ИС «Учёт техники» — ИТЭУП')
    print('  http://127.0.0.1:5000')
    print('=' * 50)
    # Раскомментируйте следующую строку, если нужно открывать браузер автоматически:
    # Timer(1.0, open_browser).start()
    app.run(host='127.0.0.1', port=5000, debug=False)
