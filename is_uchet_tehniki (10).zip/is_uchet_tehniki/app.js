// ===== Storage keys =====
const DATA_KEY = 'is_uchet_tehniki_v1';
const USERS_KEY = 'is_uchet_users_v1';
const SESSION_KEY = 'is_uchet_session';

// ===== Default demo data =====
const defaultData = {
  equipment: [
    { id: 1, invNum: 'Т-001', name: 'ПК DEXP Aquilon', model: 'Aquilon O230', serial: 'SN001234', type: 'ПК', cabinet: 'Каб. 101', responsible: 'Кузнецова М.А.', purchaseDate: '2023-09-01', cost: 45000, status: 'В эксплуатации', lastTO: '2026-03-15', note: '' },
    { id: 2, invNum: 'Т-002', name: 'ПК DEXP Aquilon', model: 'Aquilon O230', serial: 'SN001235', type: 'ПК', cabinet: 'Каб. 101', responsible: 'Кузнецова М.А.', purchaseDate: '2023-09-01', cost: 45000, status: 'В эксплуатации', lastTO: '2026-03-15', note: '' },
    { id: 3, invNum: 'Т-003', name: 'ПК DEXP Aquilon', model: 'Aquilon O230', serial: 'SN001236', type: 'ПК', cabinet: 'Каб. 102', responsible: 'Новиков И.С.', purchaseDate: '2023-09-01', cost: 45000, status: 'В эксплуатации', lastTO: '2026-02-20', note: '' },
    { id: 4, invNum: 'Т-004', name: 'ПК DEXP Aquilon', model: 'Aquilon O230', serial: 'SN001237', type: 'ПК', cabinet: 'Каб. 101', responsible: 'Кузнецова М.А.', purchaseDate: '2023-09-01', cost: 45000, status: 'В ремонте', lastTO: '2025-11-10', note: 'Не включается БП' },
    { id: 5, invNum: 'Т-005', name: 'Ноутбук ASUS', model: 'VivoBook 15', serial: 'ASU98765', type: 'Ноутбук', cabinet: 'Каб. 205', responsible: 'Волкова О.Д.', purchaseDate: '2024-01-15', cost: 52000, status: 'В эксплуатации', lastTO: '2026-04-01', note: '' },
    { id: 6, invNum: 'Т-006', name: 'Ноутбук Lenovo', model: 'IdeaPad 3', serial: 'LEN54321', type: 'Ноутбук', cabinet: 'Каб. 205', responsible: 'Волкова О.Д.', purchaseDate: '2024-01-15', cost: 48000, status: 'В эксплуатации', lastTO: '2026-04-01', note: '' },
    { id: 7, invNum: 'Т-007', name: 'Проектор Epson', model: 'EB-X51', serial: 'EPX11223', type: 'Проектор', cabinet: 'Каб. 101', responsible: 'Кузнецова М.А.', purchaseDate: '2022-08-20', cost: 38000, status: 'В эксплуатации', lastTO: '2025-12-05', note: '' },
    { id: 8, invNum: 'Т-008', name: 'Интерактивная доска', model: 'Smart Board 600', serial: 'SB600998', type: 'Интерактивная доска', cabinet: 'Каб. 102', responsible: 'Новиков И.С.', purchaseDate: '2021-05-10', cost: 95000, status: 'В эксплуатации', lastTO: '2026-01-20', note: '' },
    { id: 9, invNum: 'Т-009', name: 'Коммутатор Cisco', model: 'SG350-28', serial: 'CSG350001', type: 'Сетевое оборудование', cabinet: 'Серверная', responsible: 'Смирнов А.В.', purchaseDate: '2022-03-01', cost: 65000, status: 'В эксплуатации', lastTO: '2025-10-15', note: '' },
    { id: 10, invNum: 'Т-010', name: 'Сервер Dell T140', model: 'PowerEdge T140', serial: 'DELLT14001', type: 'Сервер', cabinet: 'Серверная', responsible: 'Смирнов А.В.', purchaseDate: '2021-11-20', cost: 120000, status: 'В эксплуатации', lastTO: '2026-05-10', note: 'Основной сервер' },
    { id: 11, invNum: 'Т-011', name: 'ПК DEXP Aquilon', model: 'Aquilon O230', serial: 'SN001240', type: 'ПК', cabinet: 'Каб. 203', responsible: 'Соколов П.А.', purchaseDate: '2023-09-01', cost: 45000, status: 'На складе', lastTO: '', note: 'Резерв' },
    { id: 12, invNum: 'Т-012', name: 'Принтер HP', model: 'LaserJet Pro M404', serial: 'HPM40455', type: 'Периферия', cabinet: 'Каб. 102', responsible: 'Новиков И.С.', purchaseDate: '2023-02-14', cost: 22000, status: 'В эксплуатации', lastTO: '2025-09-01', note: '' },
    { id: 13, invNum: 'Т-013', name: 'МФУ Canon', model: 'i-SENSYS MF443', serial: 'CNMF44312', type: 'Периферия', cabinet: 'Каб. 205', responsible: 'Волкова О.Д.', purchaseDate: '2022-06-30', cost: 35000, status: 'В эксплуатации', lastTO: '2026-02-28', note: '' },
    { id: 14, invNum: 'Т-014', name: 'Ноутбук HP', model: 'ProBook 450', serial: 'HPPB45077', type: 'Ноутбук', cabinet: 'Каб. 203', responsible: 'Соколов П.А.', purchaseDate: '2020-09-01', cost: 42000, status: 'В ремонте', lastTO: '2025-08-12', note: 'Проблемы с батареей' },
    { id: 15, invNum: 'Т-015', name: 'Веб-камера Logitech', model: 'C920', serial: 'LOGC92099', type: 'Периферия', cabinet: 'Каб. 102', responsible: 'Новиков И.С.', purchaseDate: '2019-04-10', cost: 7500, status: 'Списано', lastTO: '', note: 'Неисправна, списана 2025-06' }
  ],
  responsible: [
    { id: 1, fio: 'Смирнов Артём Владимирович', position: 'Системный администратор', cabinet: 'Серверная', phone: '+7 (912) 111-00-11', email: 'smirnov@iteup.ru' },
    { id: 2, fio: 'Кузнецова Мария Александровна', position: 'Преподаватель, зав. кабинетом', cabinet: 'Каб. 101', phone: '+7 (912) 222-00-22', email: 'kuznetsova@iteup.ru' },
    { id: 3, fio: 'Новиков Игорь Сергеевич', position: 'Преподаватель, зав. кабинетом', cabinet: 'Каб. 102', phone: '+7 (912) 333-00-33', email: 'novikov@iteup.ru' },
    { id: 4, fio: 'Волкова Ольга Дмитриевна', position: 'Преподаватель, зав. кабинетом', cabinet: 'Каб. 205', phone: '+7 (912) 444-00-44', email: 'volkova@iteup.ru' },
    { id: 5, fio: 'Соколов Павел Андреевич', position: 'Преподаватель, зав. кабинетом', cabinet: 'Каб. 203', phone: '+7 (912) 555-00-55', email: 'sokolov@iteup.ru' },
    { id: 6, fio: 'Шадрина Арина Юрьевна', position: 'Руководитель практики', cabinet: 'Администрация', phone: '+7 (912) 666-00-66', email: 'shadrina@iteup.ru' }
  ],
  maintenance: [
    { id: 1, date: '2026-05-10', invNum: 'Т-010', type: 'ТО', description: 'Плановое ТО: чистка, проверка дисков, обновление ПО', executor: 'Смирнов А.В.', result: 'Исправно', cost: 0 },
    { id: 2, date: '2026-04-01', invNum: 'Т-005', type: 'ТО', description: 'Чистка системы охлаждения, обновление драйверов', executor: 'Смирнов А.В.', result: 'Исправно', cost: 0 },
    { id: 3, date: '2026-04-01', invNum: 'Т-006', type: 'ТО', description: 'Чистка системы охлаждения', executor: 'Смирнов А.В.', result: 'Исправно', cost: 0 },
    { id: 4, date: '2026-03-15', invNum: 'Т-001', type: 'ТО', description: 'Плановое ТО кабинета 101', executor: 'Смирнов А.В.', result: 'Исправно', cost: 0 },
    { id: 5, date: '2026-03-15', invNum: 'Т-002', type: 'ТО', description: 'Плановое ТО кабинета 101', executor: 'Смирнов А.В.', result: 'Исправно', cost: 0 },
    { id: 6, date: '2026-02-28', invNum: 'Т-013', type: 'Ремонт', description: 'Замена картриджа и ролика захвата', executor: 'Сервис-центр', result: 'Исправно', cost: 4500 },
    { id: 7, date: '2025-11-12', invNum: 'Т-004', type: 'Диагностика', description: 'Не включается. Диагностика БП — неисправен', executor: 'Смирнов А.В.', result: 'Требует ремонта', cost: 0 },
    { id: 8, date: '2025-08-15', invNum: 'Т-014', type: 'Ремонт', description: 'Замена батареи ноутбука', executor: 'Сервис-центр', result: 'Исправно', cost: 6200 }
  ]
};

const defaultUsers = [
  {
    id: 1,
    login: 'admin',
    password: 'admin123',
    fio: 'Администратор системы',
    role: 'admin',
    created: '2026-01-01'
  }
];

// ===== State =====
let data = loadData();
let users = loadUsers();
let currentUser = null;

function loadData() {
  try {
    const raw = localStorage.getItem(DATA_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return JSON.parse(JSON.stringify(defaultData));
}

function saveData() {
  localStorage.setItem(DATA_KEY, JSON.stringify(data));
}

function loadUsers() {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  const u = JSON.parse(JSON.stringify(defaultUsers));
  localStorage.setItem(USERS_KEY, JSON.stringify(u));
  return u;
}

function saveUsers() {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function nextId(arr) {
  return arr.length ? Math.max(...arr.map(x => x.id)) + 1 : 1;
}

function isAdmin() {
  return currentUser && currentUser.role === 'admin';
}

// ===== Toast =====
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

// ===== Auth =====
function showLogin() {
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('registerForm').style.display = 'none';
  document.getElementById('loginError').textContent = '';
}

function showRegister() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('registerForm').style.display = 'block';
  document.getElementById('regError').textContent = '';
}

function doLogin(ev) {
  ev.preventDefault();
  const login = document.getElementById('loginUser').value.trim().toLowerCase();
  const pass = document.getElementById('loginPass').value;
  const err = document.getElementById('loginError');

  const user = users.find(u => u.login.toLowerCase() === login && u.password === pass);
  if (!user) {
    err.textContent = 'Неверный логин или пароль';
    return;
  }

  currentUser = { id: user.id, login: user.login, fio: user.fio, role: user.role };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  enterApp();
}

function doRegister(ev) {
  ev.preventDefault();
  const fio = document.getElementById('regFio').value.trim();
  const login = document.getElementById('regUser').value.trim().toLowerCase();
  const pass = document.getElementById('regPass').value;
  const pass2 = document.getElementById('regPass2').value;
  const err = document.getElementById('regError');

  if (pass !== pass2) {
    err.textContent = 'Пароли не совпадают';
    return;
  }
  if (pass.length < 6) {
    err.textContent = 'Пароль должен быть не менее 6 символов';
    return;
  }
  if (users.some(u => u.login.toLowerCase() === login)) {
    err.textContent = 'Логин уже занят';
    return;
  }

  const newUser = {
    id: nextId(users),
    login,
    password: pass,
    fio,
    role: 'user',
    created: new Date().toISOString().slice(0, 10)
  };
  users.push(newUser);
  saveUsers();

  currentUser = { id: newUser.id, login: newUser.login, fio: newUser.fio, role: newUser.role };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  showToast('Регистрация успешна');
  enterApp();
}

function doLogout() {
  currentUser = null;
  sessionStorage.removeItem(SESSION_KEY);
  document.getElementById('appScreen').style.display = 'none';
  document.getElementById('authScreen').style.display = 'flex';
  document.getElementById('loginForm').reset();
  document.body.classList.remove('is-admin');
  showLogin();
}

function enterApp() {
  document.getElementById('authScreen').style.display = 'none';
  document.getElementById('appScreen').style.display = 'flex';

  document.getElementById('userName').textContent = currentUser.fio;
  const roleEl = document.getElementById('userRole');
  roleEl.textContent = currentUser.role === 'admin' ? 'Администратор' : 'Пользователь';
  roleEl.className = 'user-role' + (currentUser.role === 'admin' ? ' admin' : '');
  const av = document.getElementById('userAvatar');
  if (av) av.textContent = (currentUser.fio || 'U').trim().charAt(0).toUpperCase();

  if (isAdmin()) {
    document.body.classList.add('is-admin');
  } else {
    document.body.classList.remove('is-admin');
  }

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelector('.nav-btn[data-tab="summary"]').classList.add('active');
  document.getElementById('summary').classList.add('active');
  const pt = document.getElementById('pageTitle');
  if (pt) pt.textContent = 'Сводная статистика';

  refreshSummary();
  renderEquipment();
  renderResponsible();
  renderMaintenance();
  if (isAdmin()) renderUsers();
}

// Check session on load
(function initAuth() {
  try {
    const sess = sessionStorage.getItem(SESSION_KEY);
    if (sess) {
      currentUser = JSON.parse(sess);
      const u = users.find(x => x.id === currentUser.id);
      if (u) {
        currentUser.role = u.role;
        currentUser.fio = u.fio;
        enterApp();
        return;
      }
    }
  } catch (e) {}
  document.getElementById('authScreen').style.display = 'flex';
  document.getElementById('appScreen').style.display = 'none';
})();

// ===== Tabs =====
const tabTitles = {
  summary: 'Сводная статистика',
  equipment: 'Реестр техники',
  responsible: 'Ответственные лица',
  maintenance: 'Журнал обслуживания',
  admin: 'Админ-панель',
  instruction: 'Инструкция'
};

document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    if (btn.dataset.tab === 'admin' && !isAdmin()) {
      showToast('Доступ только для администратора');
      return;
    }
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
    const pt = document.getElementById('pageTitle');
    if (pt) pt.textContent = tabTitles[btn.dataset.tab] || '';
    if (btn.dataset.tab === 'summary') refreshSummary();
    if (btn.dataset.tab === 'equipment') renderEquipment();
    if (btn.dataset.tab === 'responsible') renderResponsible();
    if (btn.dataset.tab === 'maintenance') renderMaintenance();
    if (btn.dataset.tab === 'admin') {
      renderUsers();
      renderSysInfo();
    }
  });
});

// ===== Summary =====
function refreshSummary() {
  const eq = data.equipment;
  const total = eq.length;
  const inUse = eq.filter(e => e.status === 'В эксплуатации').length;
  const inRepair = eq.filter(e => e.status === 'В ремонте').length;
  const onStock = eq.filter(e => e.status === 'На складе').length;
  const writtenOff = eq.filter(e => e.status === 'Списано').length;
  const totalCost = eq.filter(e => e.status !== 'Списано').reduce((s, e) => s + (e.cost || 0), 0);

  document.getElementById('statsGrid').innerHTML = `
    <div class="stat-card"><div class="label">Всего единиц</div><div class="value">${total}</div></div>
    <div class="stat-card green"><div class="label">В эксплуатации</div><div class="value">${inUse}</div></div>
    <div class="stat-card orange"><div class="label">В ремонте</div><div class="value">${inRepair}</div></div>
    <div class="stat-card purple"><div class="label">На складе</div><div class="value">${onStock}</div></div>
    <div class="stat-card red"><div class="label">Списано</div><div class="value">${writtenOff}</div></div>
    <div class="stat-card"><div class="label">Общая стоимость</div><div class="value">${formatMoney(totalCost)}</div></div>
  `;

  const byType = {};
  eq.forEach(e => { byType[e.type] = (byType[e.type] || 0) + 1; });
  const maxType = Math.max(...Object.values(byType), 1);
  const colors = ['#22d3ee','#34d399','#fbbf24','#a78bfa','#f87171','#38bdf8','#f472b6','#94a3b8'];
  document.getElementById('typeChart').innerHTML = Object.entries(byType)
    .sort((a, b) => b[1] - a[1])
    .map(([k, v], i) => `
      <div class="bar-row">
        <div class="bar-label">${k}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${(v / maxType) * 100}%;background:${colors[i % colors.length]}">${v}</div></div>
      </div>`).join('');

  const byStatus = {};
  eq.forEach(e => { byStatus[e.status] = (byStatus[e.status] || 0) + 1; });
  const statusColors = {
    'В эксплуатации': '#34d399',
    'В ремонте': '#fbbf24',
    'На складе': '#a78bfa',
    'Списано': '#f87171'
  };
  const maxStatus = Math.max(...Object.values(byStatus), 1);
  document.getElementById('statusChart').innerHTML = Object.entries(byStatus)
    .map(([k, v]) => `
      <div class="bar-row">
        <div class="bar-label">${k}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${(v / maxStatus) * 100}%;background:${statusColors[k] || '#64748b'}">${v}</div></div>
      </div>`).join('');
}

function formatMoney(n) {
  return new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
}

// ===== Equipment =====
function getStatusBadge(status) {
  const map = {
    'В эксплуатации': 'badge-green',
    'В ремонте': 'badge-orange',
    'На складе': 'badge-blue',
    'Списано': 'badge-gray'
  };
  const short = {
    'В эксплуатации': 'Эксплуатация',
    'В ремонте': 'Ремонт',
    'На складе': 'Склад',
    'Списано': 'Списано'
  };
  return `<span class="badge ${map[status] || 'badge-gray'}" title="${status}">${short[status] || status}</span>`;
}

function renderEquipment() {
  const tbody = document.getElementById('equipBody');
  const search = (document.getElementById('equipSearch').value || '').toLowerCase();
  const fType = document.getElementById('filterType').value;
  const fStatus = document.getElementById('filterStatus').value;
  const fCabinet = document.getElementById('filterCabinet').value;

  const types = [...new Set(data.equipment.map(e => e.type))].sort();
  const statuses = [...new Set(data.equipment.map(e => e.status))];
  const cabinets = [...new Set(data.equipment.map(e => e.cabinet))].sort();

  const typeSel = document.getElementById('filterType');
  const statusSel = document.getElementById('filterStatus');
  const cabSel = document.getElementById('filterCabinet');
  const curType = typeSel.value, curStatus = statusSel.value, curCab = cabSel.value;

  typeSel.innerHTML = '<option value="">Все типы</option>' + types.map(t => `<option value="${t}" ${t === curType ? 'selected' : ''}>${t}</option>`).join('');
  statusSel.innerHTML = '<option value="">Все статусы</option>' + statuses.map(s => `<option value="${s}" ${s === curStatus ? 'selected' : ''}>${s}</option>`).join('');
  cabSel.innerHTML = '<option value="">Все кабинеты</option>' + cabinets.map(c => `<option value="${c}" ${c === curCab ? 'selected' : ''}>${c}</option>`).join('');

  let list = data.equipment.filter(e => {
    if (fType && e.type !== fType) return false;
    if (fStatus && e.status !== fStatus) return false;
    if (fCabinet && e.cabinet !== fCabinet) return false;
    if (search) {
      const str = Object.values(e).join(' ').toLowerCase();
      if (!str.includes(search)) return false;
    }
    return true;
  });

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="empty">Нет записей</td></tr>';
    return;
  }

  const adminActions = isAdmin();
  tbody.innerHTML = list.map(e => `
    <tr>
      <td><strong>${e.invNum}</strong></td>
      <td>${e.name}${e.model ? '<br><small style="color:#64748b">' + e.model + '</small>' : ''}</td>
      <td>${e.type}</td>
      <td>${e.cabinet}</td>
      <td>${e.responsible || '—'}</td>
      <td>${getStatusBadge(e.status)}</td>
      <td>${e.cost ? formatMoney(e.cost) : '—'}</td>
      ${adminActions ? `<td class="actions-cell">
        <button class="btn btn-sm btn-outline" onclick="editEquipment(${e.id})">Изменить</button>
        <button class="btn btn-sm btn-danger" onclick="deleteEquipment(${e.id})">Удалить</button>
      </td>` : '<td class="admin-only"></td>'}
    </tr>
  `).join('');
}

function filterEquipment() { renderEquipment(); }

function openEquipModal(id = null) {
  if (!isAdmin()) return;
  document.getElementById('equipForm').reset();
  document.getElementById('equipId').value = '';
  document.getElementById('equipModalTitle').textContent = id ? 'Изменить технику' : 'Добавить технику';

  const respSel = document.getElementById('responsible');
  respSel.innerHTML = '<option value="">— не назначен —</option>' +
    data.responsible.map(r => {
      const short = r.fio.split(' ').map((p, i) => i === 0 ? p : p[0] + '.').join(' ');
      return `<option value="${short}">${r.fio}</option>`;
    }).join('');

  if (id) {
    const e = data.equipment.find(x => x.id === id);
    if (!e) return;
    document.getElementById('equipId').value = e.id;
    document.getElementById('invNum').value = e.invNum;
    document.getElementById('name').value = e.name;
    document.getElementById('model').value = e.model || '';
    document.getElementById('serial').value = e.serial || '';
    document.getElementById('type').value = e.type;
    document.getElementById('cabinet').value = e.cabinet;
    document.getElementById('responsible').value = e.responsible || '';
    document.getElementById('purchaseDate').value = e.purchaseDate || '';
    document.getElementById('cost').value = e.cost || '';
    document.getElementById('status').value = e.status;
    document.getElementById('lastTO').value = e.lastTO || '';
    document.getElementById('note').value = e.note || '';
  }
  document.getElementById('equipModal').classList.add('open');
}

function editEquipment(id) { openEquipModal(id); }

function saveEquipment(ev) {
  ev.preventDefault();
  if (!isAdmin()) return;
  const id = document.getElementById('equipId').value;
  const invNum = document.getElementById('invNum').value.trim();

  const exists = data.equipment.find(e => e.invNum === invNum && String(e.id) !== String(id));
  if (exists) {
    showToast('Инвентарный номер уже существует');
    return;
  }

  const item = {
    id: id ? Number(id) : nextId(data.equipment),
    invNum,
    name: document.getElementById('name').value.trim(),
    model: document.getElementById('model').value.trim(),
    serial: document.getElementById('serial').value.trim(),
    type: document.getElementById('type').value,
    cabinet: document.getElementById('cabinet').value.trim(),
    responsible: document.getElementById('responsible').value,
    purchaseDate: document.getElementById('purchaseDate').value,
    cost: Number(document.getElementById('cost').value) || 0,
    status: document.getElementById('status').value,
    lastTO: document.getElementById('lastTO').value,
    note: document.getElementById('note').value.trim()
  };

  if (id) {
    const idx = data.equipment.findIndex(e => e.id === Number(id));
    data.equipment[idx] = item;
    showToast('Техника обновлена');
  } else {
    data.equipment.push(item);
    showToast('Техника добавлена');
  }
  saveData();
  closeModal('equipModal');
  renderEquipment();
  refreshSummary();
}

function deleteEquipment(id) {
  if (!isAdmin()) return;
  if (!confirm('Удалить запись? Рекомендуется вместо удаления менять статус на «Списано».')) return;
  data.equipment = data.equipment.filter(e => e.id !== id);
  saveData();
  renderEquipment();
  refreshSummary();
  showToast('Запись удалена');
}

// ===== Responsible =====
function renderResponsible() {
  const tbody = document.getElementById('respBody');
  if (!data.responsible.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty">Нет записей</td></tr>';
    return;
  }
  const adminActions = isAdmin();
  tbody.innerHTML = data.responsible.map(r => `
    <tr>
      <td><strong>${r.fio}</strong></td>
      <td>${r.position}</td>
      <td>${r.cabinet || '—'}</td>
      <td>${r.phone || '—'}</td>
      <td>${r.email || '—'}</td>
      ${adminActions ? `<td class="actions-cell">
        <button class="btn btn-sm btn-outline" onclick="editResponsible(${r.id})">Изменить</button>
        <button class="btn btn-sm btn-danger" onclick="deleteResponsible(${r.id})">Удалить</button>
      </td>` : '<td class="admin-only"></td>'}
    </tr>
  `).join('');
}

function openRespModal(id = null) {
  if (!isAdmin()) return;
  document.getElementById('respForm').reset();
  document.getElementById('respId').value = '';
  document.getElementById('respModalTitle').textContent = id ? 'Изменить ответственного' : 'Добавить ответственного';
  if (id) {
    const r = data.responsible.find(x => x.id === id);
    if (!r) return;
    document.getElementById('respId').value = r.id;
    document.getElementById('respFio').value = r.fio;
    document.getElementById('respPosition').value = r.position;
    document.getElementById('respCabinet').value = r.cabinet || '';
    document.getElementById('respPhone').value = r.phone || '';
    document.getElementById('respEmail').value = r.email || '';
  }
  document.getElementById('respModal').classList.add('open');
}

function editResponsible(id) { openRespModal(id); }

function saveResponsible(ev) {
  ev.preventDefault();
  if (!isAdmin()) return;
  const id = document.getElementById('respId').value;
  const item = {
    id: id ? Number(id) : nextId(data.responsible),
    fio: document.getElementById('respFio').value.trim(),
    position: document.getElementById('respPosition').value.trim(),
    cabinet: document.getElementById('respCabinet').value.trim(),
    phone: document.getElementById('respPhone').value.trim(),
    email: document.getElementById('respEmail').value.trim()
  };
  if (id) {
    const idx = data.responsible.findIndex(r => r.id === Number(id));
    data.responsible[idx] = item;
    showToast('Ответственный обновлён');
  } else {
    data.responsible.push(item);
    showToast('Ответственный добавлен');
  }
  saveData();
  closeModal('respModal');
  renderResponsible();
}

function deleteResponsible(id) {
  if (!isAdmin()) return;
  if (!confirm('Удалить ответственного?')) return;
  data.responsible = data.responsible.filter(r => r.id !== id);
  saveData();
  renderResponsible();
  showToast('Удалено');
}

// ===== Maintenance =====
function renderMaintenance() {
  const tbody = document.getElementById('maintBody');
  const list = [...data.maintenance].sort((a, b) => b.date.localeCompare(a.date));
  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="empty">Нет записей</td></tr>';
    return;
  }
  const adminActions = isAdmin();
  tbody.innerHTML = list.map(m => `
    <tr>
      <td>${formatDate(m.date)}</td>
      <td><strong>${m.invNum}</strong></td>
      <td><span class="badge ${m.type === 'Ремонт' ? 'badge-orange' : m.type === 'ТО' ? 'badge-green' : 'badge-blue'}">${m.type}</span></td>
      <td>${m.description}</td>
      <td>${m.executor || '—'}</td>
      <td>${m.result || '—'}</td>
      <td>${m.cost ? formatMoney(m.cost) : '—'}</td>
      ${adminActions ? `<td class="actions-cell">
        <button class="btn btn-sm btn-outline" onclick="editMaintenance(${m.id})">Изменить</button>
        <button class="btn btn-sm btn-danger" onclick="deleteMaintenance(${m.id})">Удалить</button>
      </td>` : '<td class="admin-only"></td>'}
    </tr>
  `).join('');
}

function formatDate(d) {
  if (!d) return '—';
  const [y, m, day] = d.split('-');
  return `${day}.${m}.${y}`;
}

function openMaintModal(id = null) {
  if (!isAdmin()) return;
  document.getElementById('maintForm').reset();
  document.getElementById('maintId').value = '';
  document.getElementById('maintModalTitle').textContent = id ? 'Изменить запись' : 'Добавить запись обслуживания';
  document.getElementById('maintDate').value = new Date().toISOString().slice(0, 10);

  const invSel = document.getElementById('maintInv');
  invSel.innerHTML = data.equipment
    .filter(e => e.status !== 'Списано')
    .map(e => `<option value="${e.invNum}">${e.invNum} — ${e.name}</option>`).join('');

  if (id) {
    const m = data.maintenance.find(x => x.id === id);
    if (!m) return;
    document.getElementById('maintId').value = m.id;
    document.getElementById('maintDate').value = m.date;
    document.getElementById('maintInv').value = m.invNum;
    document.getElementById('maintType').value = m.type;
    document.getElementById('maintDesc').value = m.description;
    document.getElementById('maintExecutor').value = m.executor || '';
    document.getElementById('maintResult').value = m.result || '';
    document.getElementById('maintCost').value = m.cost || '';
  }
  document.getElementById('maintModal').classList.add('open');
}

function editMaintenance(id) { openMaintModal(id); }

function saveMaintenance(ev) {
  ev.preventDefault();
  if (!isAdmin()) return;
  const id = document.getElementById('maintId').value;
  const item = {
    id: id ? Number(id) : nextId(data.maintenance),
    date: document.getElementById('maintDate').value,
    invNum: document.getElementById('maintInv').value,
    type: document.getElementById('maintType').value,
    description: document.getElementById('maintDesc').value.trim(),
    executor: document.getElementById('maintExecutor').value.trim(),
    result: document.getElementById('maintResult').value.trim(),
    cost: Number(document.getElementById('maintCost').value) || 0
  };

  if (id) {
    const idx = data.maintenance.findIndex(m => m.id === Number(id));
    data.maintenance[idx] = item;
    showToast('Запись обновлена');
  } else {
    data.maintenance.push(item);
    const eq = data.equipment.find(e => e.invNum === item.invNum);
    if (eq && item.type === 'ТО') {
      eq.lastTO = item.date;
    }
    showToast('Запись добавлена');
  }
  saveData();
  closeModal('maintModal');
  renderMaintenance();
}

function deleteMaintenance(id) {
  if (!isAdmin()) return;
  if (!confirm('Удалить запись обслуживания?')) return;
  data.maintenance = data.maintenance.filter(m => m.id !== id);
  saveData();
  renderMaintenance();
  showToast('Удалено');
}

// ===== Admin: Users =====
function renderUsers() {
  if (!isAdmin()) return;
  const tbody = document.getElementById('usersBody');
  tbody.innerHTML = users.map(u => `
    <tr>
      <td><strong>${u.login}</strong></td>
      <td>${u.fio}</td>
      <td><span class="role-badge ${u.role === 'admin' ? 'role-admin' : 'role-user'}">${u.role === 'admin' ? 'Админ' : 'Пользователь'}</span></td>
      <td>${formatDate(u.created)}</td>
      <td class="actions-cell">
        <button class="btn btn-sm btn-outline" onclick="editUser(${u.id})">Изменить</button>
        ${u.login !== 'admin' ? `<button class="btn btn-sm btn-danger" onclick="deleteUser(${u.id})">Удалить</button>` : ''}
      </td>
    </tr>
  `).join('');
}

function renderSysInfo() {
  if (!isAdmin()) return;
  document.getElementById('sysInfo').innerHTML = `
    <p><span class="label">Единиц техники</span><span class="val">${data.equipment.length}</span></p>
    <p><span class="label">Ответственных лиц</span><span class="val">${data.responsible.length}</span></p>
    <p><span class="label">Записей обслуживания</span><span class="val">${data.maintenance.length}</span></p>
    <p><span class="label">Пользователей</span><span class="val">${users.length}</span></p>
    <p><span class="label">Текущий пользователь</span><span class="val">${currentUser.fio}</span></p>
  `;
}

function openUserModal(id = null) {
  if (!isAdmin()) return;
  document.getElementById('userForm').reset();
  document.getElementById('userId').value = '';
  document.getElementById('userModalTitle').textContent = id ? 'Изменить пользователя' : 'Добавить пользователя';
  document.getElementById('passHint').textContent = id ? '(оставьте пустым, чтобы не менять)' : '*';
  document.getElementById('userPass').required = !id;

  if (id) {
    const u = users.find(x => x.id === id);
    if (!u) return;
    document.getElementById('userId').value = u.id;
    document.getElementById('userFio').value = u.fio;
    document.getElementById('userLogin').value = u.login;
    document.getElementById('userRole').value = u.role;
    document.getElementById('userLogin').readOnly = (u.login === 'admin');
  } else {
    document.getElementById('userLogin').readOnly = false;
  }
  document.getElementById('userModal').classList.add('open');
}

function editUser(id) { openUserModal(id); }

function saveUser(ev) {
  ev.preventDefault();
  if (!isAdmin()) return;
  const id = document.getElementById('userId').value;
  const login = document.getElementById('userLogin').value.trim().toLowerCase();
  const fio = document.getElementById('userFio').value.trim();
  const pass = document.getElementById('userPass').value;
  const role = document.getElementById('userRole').value;

  if (users.some(u => u.login.toLowerCase() === login && String(u.id) !== String(id))) {
    showToast('Логин уже занят');
    return;
  }

  if (id) {
    const idx = users.findIndex(u => u.id === Number(id));
    users[idx].fio = fio;
    users[idx].login = login;
    users[idx].role = role;
    if (pass) users[idx].password = pass;
    if (currentUser.id === Number(id)) {
      currentUser.fio = fio;
      currentUser.role = role;
      currentUser.login = login;
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
      document.getElementById('userName').textContent = fio;
      if (role !== 'admin') {
        document.body.classList.remove('is-admin');
      }
    }
    showToast('Пользователь обновлён');
  } else {
    if (!pass || pass.length < 6) {
      showToast('Пароль должен быть не менее 6 символов');
      return;
    }
    users.push({
      id: nextId(users),
      login,
      password: pass,
      fio,
      role,
      created: new Date().toISOString().slice(0, 10)
    });
    showToast('Пользователь добавлен');
  }
  saveUsers();
  closeModal('userModal');
  renderUsers();
  renderSysInfo();
}

function deleteUser(id) {
  if (!isAdmin()) return;
  const u = users.find(x => x.id === id);
  if (!u || u.login === 'admin') {
    showToast('Нельзя удалить основного администратора');
    return;
  }
  if (u.id === currentUser.id) {
    showToast('Нельзя удалить самого себя');
    return;
  }
  if (!confirm('Удалить пользователя «' + u.login + '»?')) return;
  users = users.filter(x => x.id !== id);
  saveUsers();
  renderUsers();
  renderSysInfo();
  showToast('Пользователь удалён');
}

function resetDemoData() {
  if (!isAdmin()) return;
  if (!confirm('Сбросить все данные техники к демонстрационным? Пользователи не будут затронуты.')) return;
  data = JSON.parse(JSON.stringify(defaultData));
  saveData();
  refreshSummary();
  renderEquipment();
  renderResponsible();
  renderMaintenance();
  renderSysInfo();
  showToast('Данные сброшены к демо');
}

// ===== Modals =====
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

document.querySelectorAll('.modal').forEach(m => {
  m.addEventListener('click', e => {
    if (e.target === m) m.classList.remove('open');
  });
});

// ===== Export / Import =====
function exportData() {
  if (!isAdmin()) return;
  const full = { data, users };
  const blob = new Blob([JSON.stringify(full, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'Uchet_tehniki_' + new Date().toISOString().slice(0, 10) + '.json';
  a.click();
  showToast('Данные экспортированы');
}

function importData() {
  if (!isAdmin()) return;
  document.getElementById('importFile').click();
}

function handleImport(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const imported = JSON.parse(e.target.result);
      if (imported.data) {
        data = imported.data;
        saveData();
      } else if (imported.equipment) {
        data = imported;
        saveData();
      } else {
        throw new Error('Неверный формат');
      }
      if (imported.users && Array.isArray(imported.users)) {
        const valid = imported.users.filter(u => u.password && u.password !== '***');
        if (valid.length) {
          users = valid;
          saveUsers();
        }
      }
      refreshSummary();
      renderEquipment();
      renderResponsible();
      renderMaintenance();
      if (isAdmin()) {
        renderUsers();
        renderSysInfo();
      }
      showToast('Данные импортированы');
    } catch (err) {
      showToast('Ошибка импорта: неверный файл');
    }
  };
  reader.readAsText(file);
  ev.target.value = '';
}
